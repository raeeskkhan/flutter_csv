//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<csv_reader/CsvReaderPlugin.h>)
#import <csv_reader/CsvReaderPlugin.h>
#else
@import csv_reader;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [CsvReaderPlugin registerWithRegistrar:[registry registrarForPlugin:@"CsvReaderPlugin"]];
}

@end
